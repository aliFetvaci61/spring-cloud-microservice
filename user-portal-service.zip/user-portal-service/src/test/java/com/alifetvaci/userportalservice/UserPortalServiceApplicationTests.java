package com.alifetvaci.userportalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserPortalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
