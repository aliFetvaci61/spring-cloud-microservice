package com.alifetvaci.userportalservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserPortalServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserPortalServiceApplication.class, args);
	}

}
